#pragma once

namespace Pantalla {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Prueba
	/// </summary>
	public ref class Prueba : public System::Windows::Forms::Form
	{
	public:
		Prueba(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Prueba()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  Registro;
	protected: 
	private: System::Windows::Forms::Button^  Aceptar;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->Registro = (gcnew System::Windows::Forms::Label());
			this->Aceptar = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// Registro
			// 
			this->Registro->AutoSize = true;
			this->Registro->Location = System::Drawing::Point(29, 45);
			this->Registro->Name = L"Registro";
			this->Registro->Size = System::Drawing::Size(87, 13);
			this->Registro->TabIndex = 0;
			this->Registro->Text = L"Ingresar Registro";
			// 
			// Aceptar
			// 
			this->Aceptar->Location = System::Drawing::Point(185, 184);
			this->Aceptar->Name = L"Aceptar";
			this->Aceptar->Size = System::Drawing::Size(75, 23);
			this->Aceptar->TabIndex = 1;
			this->Aceptar->Text = L"Acaptar";
			this->Aceptar->UseVisualStyleBackColor = true;
			// 
			// Prueba
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(529, 359);
			this->Controls->Add(this->Aceptar);
			this->Controls->Add(this->Registro);
			this->Name = L"Prueba";
			this->Text = L"UPSA";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	};
}
